function beforePack(path)
end